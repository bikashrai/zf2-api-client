<?php

return array(
    'roles' => array(
        'guest',
        'member'
    ),
    'permissions' => array(
        'member' => array(
            'feeds',
            'feeds-subscribe',
            'feeds-unsubscribe'
        )
    )
);