<?php

return array(
    'roles' => array(
        'guest',
        'member'
    ),
    'permissions' => array(
        'member' => array(
            'wall'
        )
    )
);